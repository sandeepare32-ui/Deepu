# REBEL'S Android starter project

A Kotlin + Jetpack Compose UI starter for the Rebel's dynamic gaming tournament app.

## Open the project
1. Install Android Studio (current stable version).
2. Open this `Rebels` folder in Android Studio.
3. Let Gradle sync complete; install Android SDK Platform 35 if prompted.
4. Run on an emulator or Android phone with USB debugging enabled.
5. To build an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important status
This is a **UI prototype/starter project**, not a production-ready tournament service and no compiled APK is included. Login role selection is demo-only, data is held in app memory, and Join buttons are placeholders. Do not use it to collect real payments or user credentials yet.

## Required before production
- Create a Firebase project and register Android package `com.rebels.app`.
- Add the Firebase Android configuration file and Firebase BoM, Authentication, and Firestore dependencies.
- Implement real username/password account mapping, password reset/change flows, and secure session handling. Firebase Authentication uses email/phone identifiers by default; username login needs a safe mapping strategy.
- Set admin roles only from a trusted server/Admin SDK; never let a client make itself admin.
- Write and test Firestore security rules for users, games, tournaments, registrations, and payment submissions.
- Replace in-memory game/match lists with Firestore listeners and repositories.
- Implement real registration capacity checks, duplicate-registration prevention, payment review, privacy policy, refund rules, and app testing.
- Add your official UPI receiver details only after verification. Never ask users for UPI PINs or OTPs.

## Current prototype features
- Rebel's dark/red mobile UI
- Demo User/Admin-preview sign-in screen
- CS, BR, LW, About bottom navigation
- Add and remove game names in local memory
- Create sample tournament cards
- Editable placeholder UPI receiver/UPI ID
- Terms and conditions display
