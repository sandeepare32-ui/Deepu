package com.rebels.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101014)
private val Panel = Color(0xFF1C1C23)
private val RebelRed = Color(0xFFE53945)
private val Soft = Color(0xFFB7B7C2)

data class Game(val name: String, val category: String = "Tournament")
data class Match(val game: String, val title: String, val fee: String, val prize: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = RebelRed, background = Ink, surface = Panel)) { RebelsApp() } }
    }
}

@Composable
fun RebelsApp() {
    var loggedIn by remember { mutableStateOf(false) }
    var admin by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("HOME") }
    var error by remember { mutableStateOf("") }
    var newGame by remember { mutableStateOf("") }
    var newTitle by remember { mutableStateOf("") }
    var newFee by remember { mutableStateOf("") }
    var newPrize by remember { mutableStateOf("") }
    var upi by remember { mutableStateOf("yourname@upi") }
    var receiver by remember { mutableStateOf("Your payment receiver name") }
    var showAddMatch by remember { mutableStateOf(false) }
    val games = remember { mutableStateListOf(Game("Free Fire", "BR"), Game("Counter-Strike", "CS")) }
    val matches = remember { mutableStateListOf(Match("Free Fire", "Daily BR Match", "₹20", "₹100"), Match("Counter-Strike", "CS Squad Match", "₹30", "₹150")) }

    if (!loggedIn) {
        Column(Modifier.fillMaxSize().background(Ink).padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("REBEL'S", fontSize = 34.sp, fontWeight = FontWeight.Black, color = RebelRed)
            Text("GAMING TOURNAMENTS", color = Soft, letterSpacing = 2.sp)
            Spacer(Modifier.height(30.dp))
            Text("Sign in", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(username, { username = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(password, { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(12.dp))
            Text("Prototype preview: choose a demo role", color = Soft, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { admin = false; error = "" }, colors = ButtonDefaults.buttonColors(containerColor = if (!admin) RebelRed else Panel)) { Text("User") }
                Button(onClick = { admin = true; error = "" }, colors = ButtonDefaults.buttonColors(containerColor = if (admin) RebelRed else Panel)) { Text("Admin preview") }
            }
            Button(onClick = { if (username.isBlank() || password.isBlank()) error = "Enter a username and password" else { loggedIn = true; page = if (admin) "ADMIN" else "HOME"; error = "" } }, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = RebelRed)) { Text("LOGIN") }
            if (error.isNotBlank()) Text(error, color = RebelRed)
            Spacer(Modifier.height(12.dp))
            Text("Demo only: this preview does not securely authenticate accounts. Configure Firebase before real use.", color = Soft, fontSize = 12.sp)
        }
        return
    }

    Scaffold(containerColor = Ink, bottomBar = {
        NavigationBar(containerColor = Panel) {
            listOf("CS", "BR", "LW", "ABOUT").forEach { tab ->
                NavigationBarItem(selected = page == tab, onClick = { page = tab }, icon = { Icon(when(tab){"CS"->Icons.Default.SportsEsports;"BR"->Icons.Default.Shield;"LW"->Icons.Default.Bolt;else->Icons.Default.Info}, contentDescription = tab) }, label = { Text(tab, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = RebelRed, selectedTextColor = RebelRed, indicatorColor = Color(0xFF382126)))
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().background(Ink).padding(padding).padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column { Text("REBEL'S", color = RebelRed, fontWeight = FontWeight.Black, fontSize = 25.sp); Text(if (admin) "ADMIN PREVIEW" else "TOURNAMENT ARENA", color = Soft, fontSize = 10.sp, letterSpacing = 1.5.sp) }
                IconButton(onClick = { loggedIn = false; password = "" }) { Icon(Icons.Default.Logout, "Logout", tint = RebelRed) }
            }
            when (page) {
                "ADMIN" -> {
                    Text("Admin Panel", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Add any game and create matches. This local preview saves changes only while open.", color = Soft, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(newGame, { newGame = it }, label = { Text("New game name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = { if (newGame.isNotBlank() && games.none { it.name.equals(newGame.trim(), true) }) { games.add(Game(newGame.trim())); newGame = "" } }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = RebelRed)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("ADD GAME") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { showAddMatch = !showAddMatch }, modifier = Modifier.fillMaxWidth()) { Text(if (showAddMatch) "CANCEL MATCH" else "＋ CREATE TOURNAMENT") }
                    if (showAddMatch) {
                        GamePicker(games, onSelected = { newGame = it })
                        OutlinedTextField(newTitle, { newTitle = it }, label = { Text("Tournament title") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(newFee, { newFee = it }, label = { Text("Entry fee") }, modifier = Modifier.weight(1f)); OutlinedTextField(newPrize, { newPrize = it }, label = { Text("Prize") }, modifier = Modifier.weight(1f)) }
                        Button(onClick = { if (newGame.isNotBlank() && newTitle.isNotBlank()) { matches.add(Match(newGame, newTitle, newFee.ifBlank { "Free" }, newPrize.ifBlank { "TBA" })); newTitle = ""; newFee = ""; newPrize = ""; showAddMatch = false } }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = RebelRed)) { Text("SAVE TOURNAMENT") }
                    }
                    Spacer(Modifier.height(14.dp)); Text("Games (${games.size})", fontWeight = FontWeight.Bold)
                    LazyColumn { items(games) { game -> Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(game.name, Modifier.weight(1f)); IconButton(onClick = { games.remove(game); matches.removeAll { it.game == game.name } }) { Icon(Icons.Default.Delete, "Delete ${game.name}", tint = RebelRed) } } } }
                }
                "ABOUT" -> {
                    Text("About Rebel's", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    InfoCard("UPI PAYMENTS", "Receiver: $receiver\nUPI ID: $upi\nReplace these demo details with your official payment information before launch.")
                    OutlinedTextField(receiver, { receiver = it }, label = { Text("UPI receiver name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(upi, { upi = it }, label = { Text("UPI ID") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp)); InfoCard("TERMS & CONDITIONS", "1. Provide accurate registration details.\n2. Follow each tournament's rules.\n3. Cheating and fake payment proofs are prohibited.\n4. Entry fees, prizes, refunds, and cancellation rules must be shown before joining.\n5. Payment is confirmed only after verification.\n6. Match schedules may change; updates will be announced.\n7. Never share passwords, OTPs, or UPI PINs.\n8. Personal data must be handled securely and in accordance with applicable law.")
                    InfoCard("ACCOUNT", "Signed in as: $username\nFor production, connect Firebase to securely change credentials. This preview does not save accounts.")
                    Button(onClick = { loggedIn = false; password = "" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = RebelRed)) { Text("LOG OUT") }
                }
                else -> {
                    Text(if (page == "HOME") "Discover games" else "$page TOURNAMENTS", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Pick a game. Find your next match.", color = Soft)
                    Spacer(Modifier.height(14.dp))
                    if (page == "HOME") {
                        games.forEach { game -> GameTile(game.name, "${matches.count { it.game == game.name }} tournaments", onClick = { page = if (game.category in listOf("CS", "BR", "LW")) game.category else "GAMES:${game.name}" }) }
                        Spacer(Modifier.height(10.dp)); Text("All tournaments", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        matches.forEach { MatchCard(it) }
                        if (admin) Button(onClick = { page = "ADMIN" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = RebelRed)) { Icon(Icons.Default.AdminPanelSettings, null); Text(" OPEN ADMIN PANEL") }
                    } else {
                        val filtered = if (page.startsWith("GAMES:")) matches.filter { it.game == page.removePrefix("GAMES:") } else matches.filter { it.game.contains(page, true) || (page == "BR" && it.title.contains("BR", true)) }
                        if (filtered.isEmpty()) Text("No tournaments yet. Admin can add one from the Admin Panel.", color = Soft)
                        filtered.forEach { MatchCard(it) }
                        if (admin) Button(onClick = { page = "ADMIN" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = RebelRed)) { Text("MANAGE TOURNAMENTS") }
                    }
                }
            }
        }
    }
}

@Composable fun GamePicker(games: List<Game>, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }; var selected by remember { mutableStateOf(games.firstOrNull()?.name ?: "") }
    Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Game: $selected") }; DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { games.forEach { DropdownMenuItem(text = { Text(it.name) }, onClick = { selected = it.name; onSelected(selected); expanded = false }) } } }
}

@Composable fun GameTile(name: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).background(Color(0xFF382126), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.SportsEsports, null, tint = RebelRed) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.Bold); Text(subtitle, color = Soft, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Soft)
    }
}

@Composable fun MatchCard(match: Match) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) {
        Text(match.game.uppercase(), color = RebelRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Text(match.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.height(8.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column { Text("ENTRY", color = Soft, fontSize = 10.sp); Text(match.fee, fontWeight = FontWeight.Bold) }; Column { Text("PRIZE", color = Soft, fontSize = 10.sp); Text(match.prize, fontWeight = FontWeight.Bold) } }
        Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("JOIN  ·  Demo only") }
    }
}

@Composable fun InfoCard(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Panel, RoundedCornerShape(12.dp)).padding(14.dp)) { Text(title, color = RebelRed, fontWeight = FontWeight.Bold, fontSize = 12.sp); Spacer(Modifier.height(6.dp)); Text(body, color = Soft, fontSize = 13.sp, lineHeight = 19.sp) }
}
